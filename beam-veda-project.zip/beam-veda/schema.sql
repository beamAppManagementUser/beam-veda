-- Beam Veda — D1 schema (adapted from master-spec-v2 §5)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS companies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  logo_key TEXT,               -- R2 object key instead of local logo_path
  contact TEXT DEFAULT '',
  lang_admin_default TEXT NOT NULL DEFAULT 'en',
  lang_employee_default TEXT NOT NULL DEFAULT 'en',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  pk INTEGER PRIMARY KEY AUTOINCREMENT,
  id TEXT NOT NULL COLLATE NOCASE,
  company_id INTEGER NULL REFERENCES companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,   -- PBKDF2 (Web Crypto), see src/lib/password.js
  role TEXT NOT NULL CHECK(role IN ('admin','employee')),
  active INTEGER NOT NULL DEFAULT 1,
  is_root INTEGER NOT NULL DEFAULT 0,
  lang TEXT NULL,                -- per-user language override; NULL = inherit company default
  created_at TEXT NOT NULL,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT NULL,
  UNIQUE(company_id, id)
);

CREATE TABLE IF NOT EXISTS admin_recovery (
  user_pk INTEGER PRIMARY KEY REFERENCES users(pk) ON DELETE CASCADE,
  question1 TEXT NOT NULL,
  answer1_hash TEXT NOT NULL,
  question2 TEXT NOT NULL,
  answer2_hash TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS inward_entries (
  id TEXT PRIMARY KEY,             -- UUID v4
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  customer_number TEXT NULL,
  party_name TEXT NOT NULL,
  pipe_number TEXT NULL,
  number_of_pipes INTEGER NOT NULL,
  pipe_size TEXT NULL,
  inward_date TEXT NOT NULL,
  inward_vehicle_reg TEXT NOT NULL,
  notes TEXT NULL,
  photo_key TEXT NULL,             -- R2 object key instead of has_photo flag
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_by TEXT NULL,
  updated_at TEXT NULL,
  device_info TEXT NULL
);
CREATE INDEX IF NOT EXISTS idx_inward_company ON inward_entries(company_id);

CREATE TABLE IF NOT EXISTS outward_shipments (
  id TEXT PRIMARY KEY,             -- UUID v4
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  inward_id TEXT NOT NULL REFERENCES inward_entries(id),  -- no ON DELETE CASCADE (by design)
  pipe_number TEXT NULL,
  number_of_pipes INTEGER NOT NULL,
  outward_date TEXT NOT NULL,
  outward_vehicle_reg TEXT NOT NULL,
  notes TEXT NULL,
  photo_key TEXT NULL,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_by TEXT NULL,
  updated_at TEXT NULL,
  device_info TEXT NULL
);
CREATE INDEX IF NOT EXISTS idx_outward_company ON outward_shipments(company_id);
CREATE INDEX IF NOT EXISTS idx_outward_inward ON outward_shipments(inward_id);

CREATE TABLE IF NOT EXISTS record_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  inward_id TEXT NOT NULL,
  entity_type TEXT NOT NULL CHECK(entity_type IN ('inward','outward')),
  entity_id TEXT NOT NULL,
  action TEXT NOT NULL CHECK(action IN ('create','update','delete')),
  snapshot TEXT NOT NULL,
  changed_by TEXT NOT NULL,
  changed_at TEXT NOT NULL,
  device_info TEXT
);
CREATE INDEX IF NOT EXISTS idx_history_inward ON record_history(inward_id);

CREATE TABLE IF NOT EXISTS lookup_fields (
  company_id INTEGER NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  field_key TEXT NOT NULL,
  label TEXT NOT NULL,
  use_lookup INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(company_id, field_key)
);

CREATE TABLE IF NOT EXISTS lookup_values (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  company_id INTEGER NOT NULL,
  field_key TEXT NOT NULL,
  value TEXT NOT NULL,
  UNIQUE(company_id, field_key, value),
  FOREIGN KEY(company_id, field_key) REFERENCES lookup_fields(company_id, field_key) ON DELETE CASCADE
);

-- Auto-purge / retention policy (per company) — new feature agreed on in chat
CREATE TABLE IF NOT EXISTS retention_policy (
  company_id INTEGER PRIMARY KEY REFERENCES companies(id) ON DELETE CASCADE,
  enabled INTEGER NOT NULL DEFAULT 0,
  completed_retention_days INTEGER NOT NULL DEFAULT 30,
  all_retention_days INTEGER NOT NULL DEFAULT 90
);

-- Backup run log (health-check indicator — value-add agreed on in chat)
CREATE TABLE IF NOT EXISTS backup_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL CHECK(kind IN ('system','company','auto_purge')),
  company_id INTEGER NULL,
  status TEXT NOT NULL CHECK(status IN ('success','failure')),
  detail TEXT NULL,
  ran_at TEXT NOT NULL
);

-- Seed: root user is inserted lazily by code on first request (needs a
-- runtime-computed PBKDF2 hash — see src/lib/bootstrap.js), not here.
