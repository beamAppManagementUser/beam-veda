import { all, one, run, nowIso } from "../lib/db.js";
import { hashPassword } from "../lib/password.js";
import { json, badRequest, forbidden, notFound, conflict } from "../lib/http.js";

const RESERVED_SLUGS = new Set(["root-admin", "api", "admin", "www", "app"]);
const SLUG_RE = /^[a-z0-9-]{2,60}$/;
const LOOKUP_FIELDS = [
  ["customer_number", "Customer Number"],
  ["party_name", "Party Name"],
  ["pipe_number", "Pipe Number"],
  ["pipe_size", "Pipe Size"],
  ["inward_vehicle_reg", "Inward Vehicle Reg"],
  ["outward_vehicle_reg", "Outward Vehicle Reg"],
];

function requireRoot(session) {
  if (!session || !session.isRoot) return forbidden("Root access required");
  return null;
}

// Company admin self-service — name and contact ONLY. Deliberately does NOT
// allow logo or language-default changes: logo stays root-only ("banner is
// good and pretty" as-is), and language defaults are root's call across all
// companies, not something each company sets for itself.
export async function updateOwnCompany(session, env, request) {
  if (!session || session.isRoot || session.role !== "admin") return forbidden("Company admin access required");
  const body = await request.json().catch(() => null);
  if (!body) return badRequest("Invalid body");
  const { name, contact } = body;
  const result = await run(
    env.DB,
    `UPDATE companies SET name = COALESCE(?, name), contact = COALESCE(?, contact) WHERE id = ?`,
    name ?? null, contact ?? null, session.companyId
  );
  if (result.meta.changes === 0) return notFound("Company not found");
  return json({ ok: true });
}

export async function listCompanies(session, env) {
  const err = requireRoot(session);
  if (err) return err;
  const companies = await all(env.DB, `SELECT id, slug, name, contact, active, lang_admin_default, lang_employee_default, created_at FROM companies ORDER BY name`);
  return json(companies);
}

export async function createCompany(session, env, request) {
  const err = requireRoot(session);
  if (err) return err;
  const body = await request.json().catch(() => null);
  if (!body) return badRequest("Invalid body");
  const { name, slug, contact = "", adminId, adminName, adminPassword, langAdminDefault = "en", langEmployeeDefault = "en" } = body;
  if (!name || !slug || !adminId || !adminName || !adminPassword) {
    return badRequest("name, slug, adminId, adminName, adminPassword are all required");
  }
  const normalizedSlug = String(slug).toLowerCase();
  if (!SLUG_RE.test(normalizedSlug)) return badRequest("Slug must be 2-60 lowercase letters/numbers/hyphens");
  if (RESERVED_SLUGS.has(normalizedSlug)) return badRequest("That slug is reserved");

  const existing = await one(env.DB, `SELECT id FROM companies WHERE slug = ? COLLATE NOCASE`, normalizedSlug);
  if (existing) return conflict("Slug already in use");

  const createdAt = nowIso();
  const companyResult = await run(
    env.DB,
    `INSERT INTO companies (slug, name, contact, active, lang_admin_default, lang_employee_default, created_at) VALUES (?, ?, ?, 1, ?, ?, ?)`,
    normalizedSlug, name, contact, langAdminDefault, langEmployeeDefault, createdAt
  );
  const companyId = companyResult.meta.last_row_id;

  const hash = await hashPassword(adminPassword);
  await run(
    env.DB,
    `INSERT INTO users (id, company_id, name, password_hash, role, active, is_root, created_at)
     VALUES (?, ?, ?, ?, 'admin', 1, 0, ?)`,
    adminId, companyId, adminName, hash, createdAt
  );

  // Seed lookup_fields rows per spec §5.6
  for (const [fieldKey, label] of LOOKUP_FIELDS) {
    await run(
      env.DB,
      `INSERT INTO lookup_fields (company_id, field_key, label, use_lookup) VALUES (?, ?, ?, 0)`,
      companyId, fieldKey, label
    );
  }
  await run(env.DB, `INSERT INTO retention_policy (company_id, enabled) VALUES (?, 0)`, companyId);

  return json({ id: companyId, slug: normalizedSlug, name }, 201);
}

export async function updateCompany(session, env, companyId, request) {
  const err = requireRoot(session);
  if (err) return err;
  const body = await request.json().catch(() => null);
  if (!body) return badRequest("Invalid body");
  const { name, contact, langAdminDefault, langEmployeeDefault } = body;
  const result = await run(
    env.DB,
    `UPDATE companies SET name = COALESCE(?, name), contact = COALESCE(?, contact),
     lang_admin_default = COALESCE(?, lang_admin_default), lang_employee_default = COALESCE(?, lang_employee_default)
     WHERE id = ?`,
    name ?? null, contact ?? null, langAdminDefault ?? null, langEmployeeDefault ?? null, companyId
  );
  if (result.meta.changes === 0) return notFound("Company not found");
  return json({ ok: true });
}

export async function setCompanyActive(session, env, companyId, active) {
  const err = requireRoot(session);
  if (err) return err;
  const result = await run(env.DB, `UPDATE companies SET active = ? WHERE id = ?`, active ? 1 : 0, companyId);
  if (result.meta.changes === 0) return notFound("Company not found");
  return json({ ok: true });
}

export async function deleteCompany(session, env, companyId, request) {
  const err = requireRoot(session);
  if (err) return err;
  const body = await request.json().catch(() => ({}));
  const company = await one(env.DB, `SELECT * FROM companies WHERE id = ?`, companyId);
  if (!company) return notFound("Company not found");
  if (body.confirmSlug !== company.slug) return badRequest("confirmSlug must match the company's slug exactly");

  // Ordering per spec §5.7: delete this company's outward_shipments first
  // (no-cascade FK), THEN let the companies delete cascade the rest
  // (inward_entries, users, lookup_fields/values, record_history).
  await run(env.DB, `DELETE FROM outward_shipments WHERE company_id = ?`, companyId);
  await run(env.DB, `DELETE FROM companies WHERE id = ?`, companyId);

  // Bulk-delete every file (photos + backups) belonging to this company —
  // straightforward now that all storage keys are namespaced by company.
  const list = await env.PHOTOS.list({ prefix: `companies/${companyId}/` });
  for (const obj of list.objects) await env.PHOTOS.delete(obj.key);

  return json({ ok: true, filesRemoved: list.objects.length });
}

export async function selectCompany(session, env, request) {
  const err = requireRoot(session);
  if (err) return err;
  const body = await request.json().catch(() => null);
  if (!body || !("companyId" in body)) return badRequest("companyId is required (or null for All)");
  // Session is a signed cookie, not server state, so "selecting" a company
  // means re-issuing the cookie with selectedCompanyId set. Handled in index.js
  // where the Set-Cookie header is attached — this returns the new value for it.
  return json({ selectedCompanyId: body.companyId });
}

export async function publicCompanyInfo(env, slug) {
  const company = await one(
    env.DB,
    `SELECT name, contact, logo_key, active FROM companies WHERE slug = ? COLLATE NOCASE`,
    slug
  );
  if (!company) return notFound("Unknown company");
  return json({
    name: company.name,
    contact: company.contact,
    hasLogo: !!company.logo_key,
    active: !!company.active,
  });
}

// Public (no login needed) so the logo can render on the login screen itself.
export async function publicCompanyLogo(env, slug) {
  const company = await one(env.DB, `SELECT logo_key FROM companies WHERE slug = ? COLLATE NOCASE`, slug);
  if (!company || !company.logo_key) return notFound("No logo");
  const obj = await env.PHOTOS.get(company.logo_key);
  if (!obj) return notFound("No logo");
  return new Response(obj.body, { headers: { "Content-Type": "image/png" } });
}

export async function uploadLogo(session, env, companyId, request) {
  const err = requireRoot(session);
  if (err) return err;
  const body = await request.json().catch(() => null);
  if (!body || !body.logoBase64) return badRequest("logoBase64 is required");
  const clean = body.logoBase64.includes(",") ? body.logoBase64.split(",")[1] : body.logoBase64;
  const binary = atob(clean);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const key = `companies/${companyId}/logo.png`;
  await env.PHOTOS.put(key, bytes, { httpMetadata: { contentType: "image/png" } });
  await run(env.DB, `UPDATE companies SET logo_key = ? WHERE id = ?`, key, companyId);
  return json({ ok: true });
}
